HOLY MOUNT CHURCH — SONG LYRICS WEBSITE

Open index.html in a browser to preview the website.

The site is mobile-friendly and includes:
- 10-song library
- Search box
- Tamil + Romanized Tamil titles
- Individual song pages

Next step: paste the complete lyrics into songs.json (the website reads this data).
